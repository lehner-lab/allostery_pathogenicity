#!/bin/bash
pymol 2SRC.pml
