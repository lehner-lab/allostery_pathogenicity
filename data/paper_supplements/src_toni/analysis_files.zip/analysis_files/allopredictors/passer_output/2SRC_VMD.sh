#!/bin/bash
vmd 2SRC_out.pdb -e 2SRC.tcl
